source $HOME/$ZSH_DIR/zinit/bin/zinit.zsh

zinit ice depth=1; zinit light romkatv/powerlevel10k
zinit load zdharma/history-search-multi-word

# 语法高亮
zinit ice lucid wait='0' atinit='zpcompinit'
zinit light zdharma/fast-syntax-highlighting

# 自动建议
zinit ice lucid wait="0" atload='_zsh_autosuggest_start'
zinit light zsh-users/zsh-autosuggestions

# 补全
zinit ice lucid wait='0'
zinit light zsh-users/zsh-completions


# 加载 OMZ 框架及部分插件
zinit snippet OMZ::lib/history.zsh
zinit snippet OMZ::plugins/sudo/sudo.plugin.zsh

zinit ice lucid wait='1'
zinit snippet OMZ::plugins/git/git.plugin.zsh

